# DeepSpeech2-Keras
Referencing from
1. https://github.com/mlrobsmt/KerasDeepSpeech
2. https://github.com/baidu-research/ba-dls-deepspeech
